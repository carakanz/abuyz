#!/bin/bash
#PBS -l procs=1

module load ScriptLang/python/3.5u2i

cd ${PBS_O_WORKDIR}

python test.py
