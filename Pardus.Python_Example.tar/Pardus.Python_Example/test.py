count = 0 
while count < 5:
    print(count)
    count += 1  # This is the same as count = count + 1
